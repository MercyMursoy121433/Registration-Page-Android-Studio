package com.mursoy.myemarald;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

public class Loginin extends AppCompatActivity {
    Button b1,b2;
    EditText ed1,ed2,ed3;

    TextView tx1;
    int counter = 3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginin);

        b1 = (Button)findViewById(R.id.log);
        ed1 = (EditText)findViewById(R.id.first_name);
        ed2 = (EditText)findViewById(R.id.password);
        ed3 = (EditText)findViewById(R.id.email_address);


        b2 = (Button)findViewById(R.id.button2);
        tx1 = (TextView)findViewById(R.id.log_in);
        tx1.setVisibility(View.GONE);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed1.getText().toString().equals("admin") &&
                        ed2.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(),
                            "Redirecting...",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Welcome to my App",Toast.LENGTH_SHORT).show();

                            tx1.setVisibility(View.VISIBLE);
                    tx1.setBackgroundColor(Color.RED);
                    counter--;
                    tx1.setText(Integer.toString(counter));

                    if (counter == 0) {
                        b1.setEnabled(false);
                    }
                }
            }
        });
TextView btn=findViewById(R.id.log_in);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Loginin.this,MainActivity.class));
                finish();
            }
        });
    }

    public void Cancel(View view) {
    }

    public void LogIn(View view) {
    }
}
