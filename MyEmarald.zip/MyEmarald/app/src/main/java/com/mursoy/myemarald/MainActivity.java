package com.mursoy.myemarald;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

//1.implement an interface (view.OnClick listener)which allows us to handle on click events on our calendar picker dialog
//7.0Implement interface (AdapterView.onItemSelectedListener

public class MainActivity  extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    //2 declare an edit text variable that is the focus of the calendar dialogue
    private EditText DoB;
    Button b2;
    //5.declare the variable to hold the selected date( year,month and day )
    private int mYear;
    private int mDay;
    private int mMonth;
    //7.6 Declare a variable for holding the item selected on the spinner
    private String mSpinnerLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//3.connect the edit text variable you created with the one specified in the layout for receiving the date value
        DoB = findViewById(R.id.DoB);
        b2 = findViewById(R.id.create_account);
//4 connect the edit text variable with an onclick listener
        DoB.setOnClickListener(this);
        //7.1 declare a spinner variable and connect it with the spinner view in the layout
        Spinner phoneSpinner = findViewById(R.id.phone_spinner);
        //7.2 set on item selected listener on the spinner object you ave created
        if (phoneSpinner != null) {
            phoneSpinner.setOnItemSelectedListener(this);
        }
        //7.3create an array adapter using the string array and default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.spinner_label, android.R.layout.simple_spinner_dropdown_item);
        //7.4 specify layout for dropdown menu
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //7.5 attach the spinner to the adapter
        if (phoneSpinner != null) {
            phoneSpinner.setAdapter(adapter);
        }
    }

    @Override
    public void onClick(View v) {
        //6. To get the instance of the current date
        //6.1 Ensure the focus is on the edit variable birthday
        if (v == DoB) {
            //6.2 declare a calendar to get current date
            final Calendar C = Calendar.getInstance();
            mYear = C.get(Calendar.YEAR);
            mMonth = C.get(Calendar.MONTH);
            mDay = C.get(Calendar.DAY_OF_MONTH);
//6.3 Declare a date picker dialogue to pick selected date
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    //6.4 Set the date on the edit text variable
                    DoB.setText(dayOfMonth + "-" + (month + 1 + "-" + year));
                }
            }, mYear, mMonth, mDay);
            //6.5 show date picker dialog
            datePickerDialog.show();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//7.6 Declare a variable for holding the item selected on the spinner
        //7.7 use the method get item at position() to get the label selected
        mSpinnerLabel = adapterView.getItemAtPosition(i).toString();
        //7.8 Something  to do with item selected
        Toast myToast = Toast.makeText(this, "Selected phone as:" + mSpinnerLabel, Toast.LENGTH_SHORT);
        myToast.show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
///7.9 something to do
        Toast toast = Toast.makeText(this, "nothing selected", Toast.LENGTH_SHORT);
        toast.show();

    }

    public void showToast(View view) {
        Toast check = Toast.makeText(this, "Please Accept Terms and conditions", Toast.LENGTH_SHORT);
        check.show();
    }

    public void createAccount(View view) {
        //compare passwords
        //throw error exceptions
        //get the data entered on edit text and save it on database
        //add an intent and open main Activity /login activity
        //throw a toast
        TextView btn = findViewById(R.id.create_account);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Loginin.class));
                finish();
            }
        });
    }
}